const malla = document.getElementById('malla');
malla.innerHTML = '';
const col0 = document.createElement('div');
col0.className = 'semestre año-1';
col0.innerHTML = `<h2>1er semestre</h2>`;
const quimica1 = document.createElement('div');
quimica1.className = 'ramo';
quimica1.id = 'quimica1';
quimica1.innerText = 'Química General I';
quimica1.setAttribute('data-id', 'quimica1');quimica1.setAttribute('data-unlocks', 'quimica2');
col0.appendChild(quimica1);

const matematicas1 = document.createElement('div');
matematicas1.className = 'ramo';
matematicas1.id = 'matematicas1';
matematicas1.innerText = 'Matemáticas I';
matematicas1.setAttribute('data-id', 'matematicas1');matematicas1.setAttribute('data-unlocks', 'matematicas2');
col0.appendChild(matematicas1);

const mecanica = document.createElement('div');
mecanica.className = 'ramo';
mecanica.id = 'mecanica';
mecanica.innerText = 'Mecánica y Calor';
mecanica.setAttribute('data-id', 'mecanica');mecanica.setAttribute('data-unlocks', 'optica');
col0.appendChild(mecanica);

const orientacion = document.createElement('div');
orientacion.className = 'ramo';
orientacion.id = 'orientacion';
orientacion.innerText = 'Orientación Profesional';
orientacion.setAttribute('data-id', 'orientacion');
col0.appendChild(orientacion);

const biocel = document.createElement('div');
biocel.className = 'ramo';
biocel.id = 'biocel';
biocel.innerText = 'Biología Celular';
biocel.setAttribute('data-id', 'biocel');biocel.setAttribute('data-unlocks', 'biointegral');
col0.appendChild(biocel);

malla.appendChild(col0);
const col1 = document.createElement('div');
col1.className = 'semestre año-1';
col1.innerHTML = `<h2>2do semestre</h2>`;
const quimica2 = document.createElement('div');
quimica2.className = 'ramo bloqueado';
quimica2.id = 'quimica2';
quimica2.innerText = 'Química General II';
quimica2.setAttribute('data-id', 'quimica2');quimica2.setAttribute('data-unlocks', 'fisicoquimica,organica1,analitica');
col1.appendChild(quimica2);

const matematicas2 = document.createElement('div');
matematicas2.className = 'ramo bloqueado';
matematicas2.id = 'matematicas2';
matematicas2.innerText = 'Matemáticas II';
matematicas2.setAttribute('data-id', 'matematicas2');matematicas2.setAttribute('data-unlocks', 'fisicoquimica,bioestadistica');
col1.appendChild(matematicas2);

const biointegral = document.createElement('div');
biointegral.className = 'ramo bloqueado';
biointegral.id = 'biointegral';
biointegral.innerText = 'Biología Integral';
biointegral.setAttribute('data-id', 'biointegral');biointegral.setAttribute('data-unlocks', 'histologia,anatomia');
col1.appendChild(biointegral);

const optica = document.createElement('div');
optica.className = 'ramo bloqueado';
optica.id = 'optica';
optica.innerText = 'Óptica';
optica.setAttribute('data-id', 'optica');optica.setAttribute('data-unlocks', 'instrumental');
col1.appendChild(optica);

malla.appendChild(col1);
const col2 = document.createElement('div');
col2.className = 'semestre año-2';
col2.innerHTML = `<h2>3er semestre</h2>`;
const analitica = document.createElement('div');
analitica.className = 'ramo bloqueado';
analitica.id = 'analitica';
analitica.innerText = 'Química Analítica';
analitica.setAttribute('data-id', 'analitica');analitica.setAttribute('data-unlocks', 'instrumental');
col2.appendChild(analitica);

const organica1 = document.createElement('div');
organica1.className = 'ramo bloqueado';
organica1.id = 'organica1';
organica1.innerText = 'Química Orgánica I';
organica1.setAttribute('data-id', 'organica1');organica1.setAttribute('data-unlocks', 'organica2');
col2.appendChild(organica1);

const fisicoquimica = document.createElement('div');
fisicoquimica.className = 'ramo bloqueado';
fisicoquimica.id = 'fisicoquimica';
fisicoquimica.innerText = 'Fisicoquímica';
fisicoquimica.setAttribute('data-id', 'fisicoquimica');
col2.appendChild(fisicoquimica);

const histologia = document.createElement('div');
histologia.className = 'ramo bloqueado';
histologia.id = 'histologia';
histologia.innerText = 'Histología';
histologia.setAttribute('data-id', 'histologia');
col2.appendChild(histologia);

malla.appendChild(col2);
const col3 = document.createElement('div');
col3.className = 'semestre año-2';
col3.innerHTML = `<h2>4to semestre</h2>`;
const instrumental = document.createElement('div');
instrumental.className = 'ramo bloqueado';
instrumental.id = 'instrumental';
instrumental.innerText = 'Análisis Instrumental';
instrumental.setAttribute('data-id', 'instrumental');instrumental.setAttribute('data-unlocks', 'medicamentos1,farmacognosia,bioquimica,bromatologia');
col3.appendChild(instrumental);

const organica2 = document.createElement('div');
organica2.className = 'ramo bloqueado';
organica2.id = 'organica2';
organica2.innerText = 'Química Orgánica II';
organica2.setAttribute('data-id', 'organica2');organica2.setAttribute('data-unlocks', 'bioquimica,farmacognosia,medicamentos1');
col3.appendChild(organica2);

const bioestadistica = document.createElement('div');
bioestadistica.className = 'ramo bloqueado';
bioestadistica.id = 'bioestadistica';
bioestadistica.innerText = 'Bioestadística';
bioestadistica.setAttribute('data-id', 'bioestadistica');bioestadistica.setAttribute('data-unlocks', 'saludcomunidad');
col3.appendChild(bioestadistica);

const anatomia = document.createElement('div');
anatomia.className = 'ramo bloqueado';
anatomia.id = 'anatomia';
anatomia.innerText = 'Anatomía';
anatomia.setAttribute('data-id', 'anatomia');anatomia.setAttribute('data-unlocks', 'fisiologia');
col3.appendChild(anatomia);

malla.appendChild(col3);
const col4 = document.createElement('div');
col4.className = 'semestre año-3';
col4.innerHTML = `<h2>5to semestre</h2>`;
const bioquimica = document.createElement('div');
bioquimica.className = 'ramo bloqueado';
bioquimica.id = 'bioquimica';
bioquimica.innerText = 'Bioquímica Farmacéutica';
bioquimica.setAttribute('data-id', 'bioquimica');bioquimica.setAttribute('data-unlocks', 'farmacodinamia,microbiologia,fisiopatologia,bioquimicaclinica,toxicologia,clinica2');
col4.appendChild(bioquimica);

const farmacognosia = document.createElement('div');
farmacognosia.className = 'ramo bloqueado';
farmacognosia.id = 'farmacognosia';
farmacognosia.innerText = 'Farmacognosia';
farmacognosia.setAttribute('data-id', 'farmacognosia');farmacognosia.setAttribute('data-unlocks', 'tecnologia1');
col4.appendChild(farmacognosia);

const medicamentos1 = document.createElement('div');
medicamentos1.className = 'ramo bloqueado';
medicamentos1.id = 'medicamentos1';
medicamentos1.innerText = 'Análisis de Medicamentos I';
medicamentos1.setAttribute('data-id', 'medicamentos1');medicamentos1.setAttribute('data-unlocks', 'farmaco1');
col4.appendChild(medicamentos1);

const fisiologia = document.createElement('div');
fisiologia.className = 'ramo bloqueado';
fisiologia.id = 'fisiologia';
fisiologia.innerText = 'Fisiología Farmacéutica';
fisiologia.setAttribute('data-id', 'fisiologia');fisiologia.setAttribute('data-unlocks', 'bioquimicaclinica,parasitologia,toxicologia,fisiopatologia,microbiologia,farmacodinamia,nutricion');
col4.appendChild(fisiologia);

malla.appendChild(col4);
const col5 = document.createElement('div');
col5.className = 'semestre año-3';
col5.innerHTML = `<h2>6to semestre</h2>`;
const farmacodinamia = document.createElement('div');
farmacodinamia.className = 'ramo bloqueado';
farmacodinamia.id = 'farmacodinamia';
farmacodinamia.innerText = 'Farmacodinamia';
farmacodinamia.setAttribute('data-id', 'farmacodinamia');farmacodinamia.setAttribute('data-unlocks', 'practica1,farmacodinamia2');
col5.appendChild(farmacodinamia);

const microbiologia = document.createElement('div');
microbiologia.className = 'ramo bloqueado';
microbiologia.id = 'microbiologia';
microbiologia.innerText = 'Microbiología';
microbiologia.setAttribute('data-id', 'microbiologia');microbiologia.setAttribute('data-unlocks', 'clinica1,saludcomunidad,bromatologia');
col5.appendChild(microbiologia);

const fisiopatologia = document.createElement('div');
fisiopatologia.className = 'ramo bloqueado';
fisiopatologia.id = 'fisiopatologia';
fisiopatologia.innerText = 'Fisiopatología';
fisiopatologia.setAttribute('data-id', 'fisiopatologia');fisiopatologia.setAttribute('data-unlocks', 'clinica1,nutricion');
col5.appendChild(fisiopatologia);

const farmaco1 = document.createElement('div');
farmaco1.className = 'ramo bloqueado';
farmaco1.id = 'farmaco1';
farmaco1.innerText = 'Farmacoquímica I';
farmaco1.setAttribute('data-id', 'farmaco1');farmaco1.setAttribute('data-unlocks', 'practica1,farmaco2');
col5.appendChild(farmaco1);

malla.appendChild(col5);
const col6 = document.createElement('div');
col6.className = 'semestre año-4';
col6.innerHTML = `<h2>7mo semestre</h2>`;
const practica1 = document.createElement('div');
practica1.className = 'ramo bloqueado';
practica1.id = 'practica1';
practica1.innerText = 'Práctica I';
practica1.setAttribute('data-id', 'practica1');practica1.setAttribute('data-unlocks', 'privada');
col6.appendChild(practica1);

const farmacodinamia2 = document.createElement('div');
farmacodinamia2.className = 'ramo bloqueado';
farmacodinamia2.id = 'farmacodinamia2';
farmacodinamia2.innerText = 'Farmacodinamia II';
farmacodinamia2.setAttribute('data-id', 'farmacodinamia2');farmacodinamia2.setAttribute('data-unlocks', 'clinica1,toxicologia,privada');
col6.appendChild(farmacodinamia2);

const farmaco2 = document.createElement('div');
farmaco2.className = 'ramo bloqueado';
farmaco2.id = 'farmaco2';
farmaco2.innerText = 'Farmacoquímica II';
farmaco2.setAttribute('data-id', 'farmaco2');farmaco2.setAttribute('data-unlocks', 'clinica1,toxicologia,privada');
col6.appendChild(farmaco2);

const parasitologia = document.createElement('div');
parasitologia.className = 'ramo bloqueado';
parasitologia.id = 'parasitologia';
parasitologia.innerText = 'Parasitología';
parasitologia.setAttribute('data-id', 'parasitologia');
col6.appendChild(parasitologia);

const tecnologia1 = document.createElement('div');
tecnologia1.className = 'ramo bloqueado';
tecnologia1.id = 'tecnologia1';
tecnologia1.innerText = 'Tecnología Farmacéutica I';
tecnologia1.setAttribute('data-id', 'tecnologia1');tecnologia1.setAttribute('data-unlocks', 'tecnologia2');
col6.appendChild(tecnologia1);

const saludcomunidad = document.createElement('div');
saludcomunidad.className = 'ramo bloqueado';
saludcomunidad.id = 'saludcomunidad';
saludcomunidad.innerText = 'Salud y Comunidad';
saludcomunidad.setAttribute('data-id', 'saludcomunidad');
col6.appendChild(saludcomunidad);

malla.appendChild(col6);
const col7 = document.createElement('div');
col7.className = 'semestre año-4';
col7.innerHTML = `<h2>8vo semestre</h2>`;
const clinica1 = document.createElement('div');
clinica1.className = 'ramo bloqueado';
clinica1.id = 'clinica1';
clinica1.innerText = 'Farmacia Clínica I';
clinica1.setAttribute('data-id', 'clinica1');clinica1.setAttribute('data-unlocks', 'clinica2');
col7.appendChild(clinica1);

const toxicologia = document.createElement('div');
toxicologia.className = 'ramo bloqueado';
toxicologia.id = 'toxicologia';
toxicologia.innerText = 'Toxicología Farmacéutica';
toxicologia.setAttribute('data-id', 'toxicologia');
col7.appendChild(toxicologia);

const tecnologia2 = document.createElement('div');
tecnologia2.className = 'ramo bloqueado';
tecnologia2.id = 'tecnologia2';
tecnologia2.innerText = 'Tecnología Farmacéutica II';
tecnologia2.setAttribute('data-id', 'tecnologia2');tecnologia2.setAttribute('data-unlocks', 'legislacion,biofarmacia,privada');
col7.appendChild(tecnologia2);

const bioquimicaclinica = document.createElement('div');
bioquimicaclinica.className = 'ramo bloqueado';
bioquimicaclinica.id = 'bioquimicaclinica';
bioquimicaclinica.innerText = 'Bioquímica Clínica';
bioquimicaclinica.setAttribute('data-id', 'bioquimicaclinica');
col7.appendChild(bioquimicaclinica);

malla.appendChild(col7);
const col8 = document.createElement('div');
col8.className = 'semestre año-5';
col8.innerHTML = `<h2>9no semestre</h2>`;
const privada = document.createElement('div');
privada.className = 'ramo bloqueado';
privada.id = 'privada';
privada.innerText = 'Práctica Privada';
privada.setAttribute('data-id', 'privada');privada.setAttribute('data-unlocks', 'terminalpriv');
col8.appendChild(privada);

const clinica2 = document.createElement('div');
clinica2.className = 'ramo bloqueado';
clinica2.id = 'clinica2';
clinica2.innerText = 'Farmacia Clínica II';
clinica2.setAttribute('data-id', 'clinica2');clinica2.setAttribute('data-unlocks', 'clinica3,terminalpriv,terminalasis');
col8.appendChild(clinica2);

const nutricion = document.createElement('div');
nutricion.className = 'ramo bloqueado';
nutricion.id = 'nutricion';
nutricion.innerText = 'Nutrición Farmacéutica';
nutricion.setAttribute('data-id', 'nutricion');
col8.appendChild(nutricion);

const biofarmacia = document.createElement('div');
biofarmacia.className = 'ramo bloqueado';
biofarmacia.id = 'biofarmacia';
biofarmacia.innerText = 'Biofarmacia';
biofarmacia.setAttribute('data-id', 'biofarmacia');biofarmacia.setAttribute('data-unlocks', 'terminalpriv');
col8.appendChild(biofarmacia);

const legislacion = document.createElement('div');
legislacion.className = 'ramo bloqueado';
legislacion.id = 'legislacion';
legislacion.innerText = 'Legislación Farmacéutica';
legislacion.setAttribute('data-id', 'legislacion');legislacion.setAttribute('data-unlocks', 'admin');
col8.appendChild(legislacion);

const bromatologia = document.createElement('div');
bromatologia.className = 'ramo bloqueado';
bromatologia.id = 'bromatologia';
bromatologia.innerText = 'Bromatología';
bromatologia.setAttribute('data-id', 'bromatologia');
col8.appendChild(bromatologia);

malla.appendChild(col8);
const col9 = document.createElement('div');
col9.className = 'semestre año-5';
col9.innerHTML = `<h2>10mo semestre</h2>`;
const clinica3 = document.createElement('div');
clinica3.className = 'ramo bloqueado';
clinica3.id = 'clinica3';
clinica3.innerText = 'Farmacia Clínica III';
clinica3.setAttribute('data-id', 'clinica3');
col9.appendChild(clinica3);

const admin = document.createElement('div');
admin.className = 'ramo bloqueado';
admin.id = 'admin';
admin.innerText = 'Administración Farmacéutica';
admin.setAttribute('data-id', 'admin');admin.setAttribute('data-unlocks', 'terminalpriv');
col9.appendChild(admin);

malla.appendChild(col9);
const col10 = document.createElement('div');
col10.className = 'semestre año-6';
col10.innerHTML = `<h2>11vo semestre</h2>`;
const terminalpriv = document.createElement('div');
terminalpriv.className = 'ramo bloqueado';
terminalpriv.id = 'terminalpriv';
terminalpriv.innerText = 'Práctica Terminal Farmacia Privada';
terminalpriv.setAttribute('data-id', 'terminalpriv');terminalpriv.setAttribute('data-unlocks', 'habilitacion,titulo');
col10.appendChild(terminalpriv);

const terminalasis = document.createElement('div');
terminalasis.className = 'ramo bloqueado';
terminalasis.id = 'terminalasis';
terminalasis.innerText = 'Práctica Farmacia Asistencial';
terminalasis.setAttribute('data-id', 'terminalasis');terminalasis.setAttribute('data-unlocks', 'habilitacion,titulo');
col10.appendChild(terminalasis);

malla.appendChild(col10);
const col11 = document.createElement('div');
col11.className = 'semestre año-6';
col11.innerHTML = `<h2>12vo semestre</h2>`;
const habilitacion = document.createElement('div');
habilitacion.className = 'ramo bloqueado';
habilitacion.id = 'habilitacion';
habilitacion.innerText = 'Habilitación Profesional I';
habilitacion.setAttribute('data-id', 'habilitacion');
col11.appendChild(habilitacion);

const titulo = document.createElement('div');
titulo.className = 'ramo bloqueado';
titulo.id = 'titulo';
titulo.innerText = 'Examen de Título';
titulo.setAttribute('data-id', 'titulo');
col11.appendChild(titulo);

malla.appendChild(col11);

document.querySelectorAll('.ramo').forEach(ramo => {
  if (!ramo.classList.contains('bloqueado')) {
    ramo.addEventListener('click', desbloquear);
  }
});

function desbloquear(evt) {
  const ramo = evt.currentTarget;
  ramo.classList.add('aprobado');
  const targets = ramo.dataset.unlocks?.split(',') || [];
  targets.forEach(id => {
    const desbloqueado = document.getElementById(id);
    if (desbloqueado && desbloqueado.classList.contains('bloqueado')) {
      desbloqueado.classList.remove('bloqueado');
      desbloqueado.addEventListener('click', desbloquear);
    }
  });
}
